<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// ===== TELEGRAM CONFIG - Same bot for all deposit/withdraw alerts =====
$botToken = '8990709020:AAEB7MUXvgPN2lgqPJ9oMiOdx6yMVh9V4hU';
$chatId = '8591379261';

$input = json_decode(file_get_contents('php://input'), true);
$text = isset($input['text']) ? $input['text'] : '';

if (empty($text)) {
    echo json_encode(['ok' => false, 'error' => 'No text']);
    exit;
}

$data = [
    'chat_id' => $chatId,
    'text' => $text,
    'parse_mode' => 'HTML',
    'disable_web_page_preview' => true
];

// Multiple endpoints for reliability (some hosts block api.telegram.org)
$endpoints = [
    "https://api.telegram.org/bot{$botToken}/sendMessage",
    "https://149.154.167.220/bot{$botToken}/sendMessage",
    "https://91.108.56.113/bot{$botToken}/sendMessage"
];

$sent = false;
$lastError = '';

foreach ($endpoints as $url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Host: api.telegram.org'
    ]);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 8);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);

    $result = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);

    if ($httpCode == 200 && $result) {
        $response = json_decode($result, true);
        if (isset($response['ok']) && $response['ok'] === true) {
            echo $result;
            $sent = true;
            break;
        }
        $lastError = $response['description'] ?? 'API error';
    } else {
        $lastError = $curlError ?: ("HTTP $httpCode");
    }
}

if (!$sent) {
    // Fallback with file_get_contents
    $url = "https://api.telegram.org/bot{$botToken}/sendMessage";
    $options = [
        'http' => [
            'header'  => "Content-type: application/json\r\n",
            'method'  => 'POST',
            'content' => json_encode($data),
            'timeout' => 10,
            'ignore_errors' => true
        ],
        'ssl' => [
            'verify_peer' => false,
            'verify_peer_name' => false
        ]
    ];
    $context = stream_context_create($options);
    $result = @file_get_contents($url, false, $context);
    if ($result !== false) {
        echo $result;
    } else {
        echo json_encode(['ok' => false, 'error' => $lastError ?: 'Request failed']);
    }
}
